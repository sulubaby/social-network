export class Notification {

}